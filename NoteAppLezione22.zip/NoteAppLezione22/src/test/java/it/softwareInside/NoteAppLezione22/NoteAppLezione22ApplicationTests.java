package it.softwareInside.NoteAppLezione22;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NoteAppLezione22ApplicationTests {

	@Test
	void contextLoads() {
	}

}
