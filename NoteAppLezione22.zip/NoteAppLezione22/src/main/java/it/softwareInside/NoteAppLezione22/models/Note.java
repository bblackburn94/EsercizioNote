package it.softwareInside.NoteAppLezione22.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

@Entity
public class Note {

	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	private int id;
	@NotNull(message = "il testo non deve essere NULL")
	@NotEmpty(message = "il testo non può essere vuoto")
	private String text;
	
	@NotNull(message = "l'autore non deve essere NULL")
	@NotEmpty(message = "L'autore non puo essere vuoto")
	private String autore;
	

	
	
	public Note(String autore, String text) {
		super();
		this.autore = autore;
		this.text = text;
	}
}
