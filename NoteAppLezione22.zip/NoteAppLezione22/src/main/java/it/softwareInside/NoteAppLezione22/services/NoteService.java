package it.softwareInside.NoteAppLezione22.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import it.softwareInside.NoteAppLezione22.models.Note;
import it.softwareInside.NoteAppLezione22.repository.NoteRepository;
import jakarta.validation.Valid;

@Service
public class NoteService {

	@Autowired
	NoteRepository noteRepository;

	public boolean addtoDB(@Valid Note note) {

		try {
			noteRepository.save(note);
			return true;
		} catch (Exception e) {

			return false;
		}

	}

	public boolean aggiorna(@Valid Note note) {
		return addtoDB(note);
	}

	public Note cancellaNota(int id) {
		Note note = noteRepository.findById(id).get();

		noteRepository.deleteById(id);
		return note;
	}

	public Iterable<Note> vediTutte() {
		return noteRepository.findAll();
	}

}
