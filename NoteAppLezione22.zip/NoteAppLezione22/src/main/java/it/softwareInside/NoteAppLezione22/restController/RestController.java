package it.softwareInside.NoteAppLezione22.restController;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import it.softwareInside.NoteAppLezione22.models.Note;
import it.softwareInside.NoteAppLezione22.services.NoteService;

@org.springframework.web.bind.annotation.RestController
public class RestController {

	@Autowired
	NoteService noteService;
	
	

	/**
	 * Creo un Metodo che permette di effettuare la richiesta per ottenere tutte le
	 * note
	 */
	@GetMapping("/getAllNotes")
	public Iterable<Note> getAll() {
		return noteService.vediTutte();
	}

	/**
	 * realizzo un metodo che mi permette di aggiungere una nuova nota al DB
	 * 
	 * @BB94
	 */
	@PostMapping("/addNew")
	public String addNew(@RequestBody() Note note) {
		if (noteService.addtoDB(note))
			return "NOTA AGGIUNTA CORRETTAMENTE";
		return "ERRORE! NON E STATO POSSIBILE AGGIUNGERE L'ELEMENTO AL DB";
	}
	/*
	 * realizzo un metodo che aggiorna una nota già esistente
	 */
	@PostMapping("update")
	public String UpdateNote(@RequestBody Note note) {
		if (noteService.addtoDB(note))
			return "ok aggiornato";
		return "ERRORE DURANTE L'AGGIORNAMENTO";
	}
	
	@DeleteMapping("/del")
	public Note del(@RequestParam("id") int id) {
		return noteService.cancellaNota(id);
	}
	
	
	

}
