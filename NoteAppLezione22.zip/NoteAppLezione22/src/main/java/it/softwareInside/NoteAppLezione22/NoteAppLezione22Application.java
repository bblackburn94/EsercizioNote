package it.softwareInside.NoteAppLezione22;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NoteAppLezione22Application {

	public static void main(String[] args) {
		SpringApplication.run(NoteAppLezione22Application.class, args);
	}

}
